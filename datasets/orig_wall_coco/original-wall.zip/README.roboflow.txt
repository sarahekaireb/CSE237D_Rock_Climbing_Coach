
Rockwall Detection - v1 Original Wall
==============================

This dataset was exported via roboflow.ai on April 27, 2022 at 8:11 PM GMT

It includes 7 images.
Rockwall are annotated in COCO Segmentation format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


